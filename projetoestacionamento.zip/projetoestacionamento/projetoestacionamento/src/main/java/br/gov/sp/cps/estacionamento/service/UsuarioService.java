package br.gov.sp.cps.estacionamento.service;

import br.gov.sp.cps.estacionamento.configuration.entity.Usuario;
import br.gov.sp.cps.estacionamento.repository.UsuarioRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    @Transactional
    public Usuario salvar(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    public Usuario buscaPorId(Long id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
    }

    @Transactional
    public Usuario editarSenha(long id, String password) {
        Usuario user = buscaPorId(id);
        user.setPassword(password);
        return usuarioRepository.save(user);
    }

    @Transactional
    public List<Usuario> buscaTodos() {
        return usuarioRepository.findAll();
    }
}
