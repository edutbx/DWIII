package br.gov.sp.cps.estacionamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoEstacionamentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoEstacionamentoApplication.class, args);
	}

}
