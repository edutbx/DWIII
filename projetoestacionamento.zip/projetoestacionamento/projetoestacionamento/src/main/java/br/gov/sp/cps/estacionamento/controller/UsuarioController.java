package br.gov.sp.cps.estacionamento.controller;

import br.gov.sp.cps.estacionamento.configuration.entity.Usuario;
import br.gov.sp.cps.estacionamento.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService; // ✅ injetado pelo Spring

    @PostMapping
    public ResponseEntity<Usuario> create(@RequestBody Usuario usuario) {
        Usuario user = usuarioService.salvar(usuario);
        return ResponseEntity.ok(user);
    }
}
