package br.gov.sp.cps.estacionamento.repository;

import br.gov.sp.cps.estacionamento.configuration.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
}
