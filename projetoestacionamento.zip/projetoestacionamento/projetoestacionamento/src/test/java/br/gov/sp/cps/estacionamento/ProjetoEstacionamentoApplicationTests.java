package br.gov.sp.cps.estacionamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoEstacionamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
